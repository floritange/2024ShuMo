import os
import pandas as pd
import matplotlib.pyplot as plt

# def get_x(data):
#     return [i for i in range(0, len(data))]

# data = pd.read_csv('training_set_2ap_loc0_nav82.csv')
# data_ap_0 = data[(data['protocol'] == 'tcp') & (data['ap_id'] == 'ap_0')]
# # data_ap_0 = data[(data['ap_id'] == 'ap_0')]
# data_ap_1 = data[(data['protocol'] == 'udp') & (data['ap_id'] == 'ap_1')]
# # data_ap_1 = data[(data['ap_id'] == 'ap_1')]
# plt.figure(figsize=(15, 3), dpi=300)
# plt.plot(get_x(data_ap_0.values), data_ap_0['seq_time'].values)
# plt.plot(get_x(data_ap_0.values), data_ap_0['eirp'].values)
# plt.plot(get_x(data_ap_1.values), data_ap_1['seq_time'].values)
# plt.savefig('tmp.png')

# data = pd.read_csv('training_set_3ap_loc33_nav88.csv')
# print(set(data['loc_id'].values))

# comm = os.getcwd() + '/dataset/'
# file_list = os.listdir(comm)

# all_ = []
# for f in file_list:
#     if f.startswith('training_'):
#         data = pd.read_csv(comm + f)
#         tmp1 = data['nss'].values
#         tmp2 = data['mcs'].values
#         tmp3 = [str(v) + '_' + str(tmp2[i]) for i, v in enumerate(tmp1)]
#         all_ += tmp3
# all_ = sorted(set(all_), reverse=False)
# print(all_)

# all_ = []
# for f in file_list:
#     if f.startswith('test_'):
#         data = pd.read_csv(comm + f)
#         tmp1 = data['nss'].values
#         tmp2 = data['mcs'].values
#         tmp3 = [str(v) + '_' + str(tmp2[i]) for i, v in enumerate(tmp1)]
#         all_ += tmp3
# all_ = sorted(set(all_), reverse=False)
# print(all_)
# # ['0_0', '1_0', '1_4', '1_5', '1_6', '1_9', '2_10', '2_11', '2_2', '2_3', '2_4', '2_5', '2_6', '2_7', '2_8', '2_9']

# 数据集扩充
# comm = os.getcwd() + '/dataset/'
# file_list = os.listdir(comm)

# all = []
# for f in file_list:
#     if f.startswith('training_set_3'):
#         data = pd.read_csv(comm + f)
#         tmp = data['throughput'].values
#         all += list(tmp)
# all = list(set(all))
# all = sorted(all, reverse=False)
# import numpy as np

# all = np.array(all)
# all = np.diff(all)
# all = list(set(all))
# all = sorted(all, reverse=False)
# import matplotlib.pyplot as plt

# plt.figure(1, figsize=(15, 2), dpi=300)
# plt.scatter([i for i in range(len(all))], all)
# plt.savefig('./tmp')
# print(min(all))  # training_set_2 training_set_3 0.00999999999999801 0.001

comm = os.getcwd() + '/dataset/'
output = os.getcwd() + '/dataset_enhance/'
file_list = os.listdir(comm)


def enhance_data(data):
    deltas = [0.001, 0.001, 0.001, 0.001, -0.005, -0.001, 0.001, -0.001]  # 0.61, 8.77, 100%, 97%, 22.8, 4.0 
    # deltas = [0.001, 0.001, 0.001, -0.004, -0.001, -0.001] # 0.4469, 11.15, 100%, 98.8%, 2.665, 109.88
    new_data = []
    cpt = 0
    for idx, line in data.iterrows():
        new_data.append(line.values)
        if line['nss'] == 2 and line['mcs'] == 11:
            cpt += 1
            if cpt % 10 == 0 or cpt % 11 == 0:
                for i in deltas:
                    line['seq_time'] = line['seq_time'] + i
                    line['throughput'] = line['throughput'] + i
                    new_data.append(line.values)
        else:
            for i in deltas:
                line['seq_time'] = line['seq_time'] + i
                line['throughput'] = line['throughput'] + i
                new_data.append(line.values)
    new_data_df = pd.DataFrame(new_data, columns=data.columns)
    return new_data_df


for f in file_list:
    if f.startswith('training_set_'):
        data = pd.read_csv(comm + f)
        data = enhance_data(data)
        data.to_csv(output + f, index=False)
