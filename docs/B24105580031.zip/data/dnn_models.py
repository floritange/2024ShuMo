import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from sklearn.preprocessing import MinMaxScaler


######## DNN #######
class DNN(nn.Module):
    def __init__(self, input_size, output_size):
        super(DNN, self).__init__()
        self.l_1 = nn.Sequential(nn.Linear(input_size, 512), nn.ReLU(), nn.Dropout(0.6))
        self.l_2 = nn.Sequential(nn.Linear(512, 256), nn.ReLU(), nn.Dropout(0.5))
        self.l_3 = nn.Sequential(nn.Linear(256, 128), nn.ReLU(), nn.Dropout(0.4))
        self.l_4 = nn.Sequential(nn.Linear(128, 64), nn.ReLU(), nn.Dropout(0.3))
        self.l_5 = nn.Sequential(nn.Linear(64, output_size))

    def forward(self, x):
        x = self.l_1(x)
        x = self.l_2(x)
        x = self.l_3(x)
        x = self.l_4(x)
        x = self.l_5(x)
        return x


# 封装的回归器
class DNNRegressor:
    def __init__(self, input_size, output_size, epochs=100, lr=0.001, batch_size=1):
        self.model = DNN(input_size, output_size)
        self.epochs = epochs
        self.lr = lr
        self.batch_size = batch_size
        self.criterion = nn.MSELoss()  # 损失函数为均方误差
        self.optimizer = optim.SGD(self.model.parameters(), lr=self.lr)
        self.scaler = MinMaxScaler()

    def fit(self, X_train, y_train):
        # 确保 X_train 和 y_train 都是 numpy 数组
        if isinstance(X_train, np.ndarray) is False:
            X_train = X_train.to_numpy()
        if isinstance(y_train, np.ndarray) is False:
            y_train = y_train.to_numpy()

        # 转换为张量
        X_train = torch.tensor(X_train, dtype=torch.float32)
        y_train = torch.tensor(y_train, dtype=torch.float32).unsqueeze(1)  # 如果是回归任务，确保 y_train 是列向量

        # 训练模型
        self.model.train()
        for epoch in range(self.epochs):
            epoch_loss = 0.0
            for i in range(0, len(X_train), self.batch_size):
                X_batch = X_train[i:i + self.batch_size]
                y_batch = y_train[i:i + self.batch_size]
                outputs = self.model(X_batch)
                loss = self.criterion(outputs, y_batch)

                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                epoch_loss += loss.item()

            if (epoch + 1) % 10 == 0:
                print(f"Epoch [{epoch+1}/{self.epochs}], Loss: {epoch_loss / len(X_train):.4f}")

    def predict(self, X_test):
        if isinstance(X_test, np.ndarray) is False:
            X_test = X_test.to_numpy()

        X_test = torch.tensor(X_test, dtype=torch.float32)

        self.model.eval()
        with torch.no_grad():
            y_pred = self.model(X_test).numpy()
        return y_pred.flatten()


################################


######## AE #######
class EncoderDecoder(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(EncoderDecoder, self).__init__()
        self.encoder = nn.Sequential(nn.Linear(input_size, hidden_size), nn.ReLU())
        self.decoder = nn.Sequential(nn.Linear(hidden_size, output_size))

    def forward(self, x):
        x = self.encoder(x)
        x = self.decoder(x)
        return x


# 封装的回归器
class EncoderDecoderRegressor:
    def __init__(self, input_size, hidden_size, output_size, epochs=100, lr=0.001, batch_size=1):
        self.model = EncoderDecoder(input_size, hidden_size, output_size)
        self.epochs = epochs
        self.lr = lr
        self.batch_size = batch_size
        self.criterion = nn.MSELoss()  # 损失函数为均方误差
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr)
        self.scaler = MinMaxScaler()

    def fit(self, X_train, y_train):
        # 确保 X_train 和 y_train 都是 numpy 数组
        if isinstance(X_train, np.ndarray) is False:
            X_train = X_train.to_numpy()
        if isinstance(y_train, np.ndarray) is False:
            y_train = y_train.to_numpy()

        # 转换为张量
        X_train = torch.tensor(X_train, dtype=torch.float32)
        y_train = torch.tensor(y_train, dtype=torch.float32).unsqueeze(1)  # 如果是回归任务，确保 y_train 是列向量

        # 训练模型
        self.model.train()
        for epoch in range(self.epochs):
            epoch_loss = 0.0
            for i in range(0, len(X_train), self.batch_size):
                X_batch = X_train[i:i + self.batch_size]
                y_batch = y_train[i:i + self.batch_size]
                outputs = self.model(X_batch)
                loss = self.criterion(outputs, y_batch)

                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                epoch_loss += loss.item()

            if (epoch + 1) % 10 == 0:
                print(f"Epoch [{epoch+1}/{self.epochs}], Loss: {epoch_loss / len(X_train):.4f}")

    def predict(self, X_test):
        if isinstance(X_test, np.ndarray) is False:
            X_test = X_test.to_numpy()

        X_test = torch.tensor(X_test, dtype=torch.float32)

        self.model.eval()
        with torch.no_grad():
            y_pred = self.model(X_test).numpy()
        return y_pred.flatten()


################################


######## VAE #########
# VAE的编码器部分
class VAEEncoder(nn.Module):
    def __init__(self, input_size, hidden_size, latent_size):
        super(VAEEncoder, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.fc_mu = nn.Linear(hidden_size, latent_size)  # 用于预测均值
        self.fc_logvar = nn.Linear(hidden_size, latent_size)  # 用于预测方差的对数

    def forward(self, x):
        h = self.relu(self.fc1(x))
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h)
        return mu, logvar


# VAE 解码器
class VAEDecoder(nn.Module):
    def __init__(self, latent_size, hidden_size, output_size):
        super(VAEDecoder, self).__init__()
        self.fc1 = nn.Linear(latent_size, hidden_size)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_size, output_size)

    def forward(self, z):
        h = self.relu(self.fc1(z))
        return self.fc2(h)


# 变分自编码器
class VAE(nn.Module):
    def __init__(self, input_size, hidden_size, latent_size, output_size):
        super(VAE, self).__init__()
        self.encoder = VAEEncoder(input_size, hidden_size, latent_size)
        self.decoder = VAEDecoder(latent_size, hidden_size, output_size)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x):
        mu, logvar = self.encoder(x)
        z = self.reparameterize(mu, logvar)
        return self.decoder(z), mu, logvar


# VAE 回归器，用于训练和预测
class VAERegressor:
    def __init__(self, input_size, hidden_size, latent_size, output_size, epochs=100, lr=0.001, batch_size=1):
        self.model = VAE(input_size, hidden_size, latent_size, output_size)
        self.epochs = epochs
        self.lr = lr
        self.batch_size = batch_size
        self.criterion = nn.MSELoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr)
        self.scaler = MinMaxScaler()

    def fit(self, X_train, y_train):
        # 确保 X_train 和 y_train 都是 numpy 数组
        if isinstance(X_train, np.ndarray) is False:
            X_train = X_train.to_numpy()
        if isinstance(y_train, np.ndarray) is False:
            y_train = y_train.to_numpy()

        # 转换为张量
        X_train = torch.tensor(X_train, dtype=torch.float32)
        y_train = torch.tensor(y_train, dtype=torch.float32).unsqueeze(1)  # 如果是回归任务，确保 y_train 是列向量

        # 训练模型
        self.model.train()
        for epoch in range(self.epochs):
            epoch_loss = 0.0
            for i in range(0, len(X_train), self.batch_size):
                X_batch = X_train[i:i + self.batch_size]
                y_batch = y_train[i:i + self.batch_size]
                outputs, mu, logvar = self.model(X_batch)
                loss = self.loss_function(outputs, y_batch, mu, logvar)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                epoch_loss += loss.item()

            # 打印每个 epoch 的损失
            if (epoch + 1) % 10 == 0:
                print(f"Epoch [{epoch + 1}/{self.epochs}], Loss: {epoch_loss / len(X_train):.4f}")

    def loss_function(self, recon_x, x, mu, logvar):
        BCE = self.criterion(recon_x, x)
        # 计算 KL 散度
        KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        return BCE + KLD

    def predict(self, X_test):
        # 确保 X_test 是 numpy 数组
        if isinstance(X_test, np.ndarray) is False:
            X_test = X_test.to_numpy()

        X_test = torch.tensor(X_test, dtype=torch.float32)
        self.model.eval()
        with torch.no_grad():
            y_pred, mu, logvar = self.model(X_test)
        return y_pred.numpy().flatten()


################################


# VAE Regressor，用于训练和预测
class VAERegressor:
    def __init__(self, input_size, hidden_size, latent_size, output_size, epochs=100, lr=0.001, batch_size=1):
        self.model = VAE(input_size, hidden_size, latent_size, output_size)
        self.epochs = epochs
        self.lr = lr
        self.batch_size = batch_size
        self.criterion = nn.MSELoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr)
        self.scaler = MinMaxScaler()

    def fit(self, X_train, y_train):
        X_train = torch.tensor(X_train, dtype=torch.float32)
        y_train = torch.tensor(y_train, dtype=torch.float32).unsqueeze(1)  # 确保 y 是列向量
        # 训练模型
        self.model.train()
        for epoch in range(self.epochs):
            epoch_loss = 0.0
            for i in range(0, len(X_train), self.batch_size):
                X_batch = X_train[i:i + self.batch_size]
                y_batch = y_train[i:i + self.batch_size]
                outputs, mu, logvar = self.model(X_batch)
                loss = self.loss_function(outputs, y_batch, mu, logvar)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                epoch_loss += loss.item()
            # 打印每个 epoch 的损失
            if (epoch + 1) % 10 == 0:
                print(f"Epoch [{epoch+1}/{self.epochs}], Loss: {epoch_loss / len(X_train):.4f}")

    def loss_function(self, recon_x, x, mu, logvar):
        BCE = self.criterion(recon_x, x)
        # 计算KL散度
        KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        return BCE + KLD

    def predict(self, X_test):
        X_test = torch.tensor(X_test, dtype=torch.float32)
        # 预测模型
        self.model.eval()
        with torch.no_grad():
            y_pred, mu, logvar = self.model(X_test)
        return y_pred.numpy().flatten()


################################
######## AE #######
class EncoderDecoderClassifier(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(EncoderDecoderClassifier, self).__init__()
        self.encoder = nn.Sequential(nn.Linear(input_size, hidden_size), nn.ReLU())
        # 输出层使用 Softmax 来进行分类
        self.classifier = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = self.encoder(x)
        x = self.classifier(x)
        return x


# 封装的分类器
class EncoderDecoderClassifierModel:
    def __init__(self, input_size, hidden_size, epochs=100, lr=0.001, batch_size=1):
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.epochs = epochs
        self.lr = lr
        self.batch_size = batch_size
        self.model = None  # 模型会在fit中初始化，依赖于y_train中的类别数
        self.criterion = nn.CrossEntropyLoss()

    def fit(self, X_train, y_train):
        # 自动确定 output_size
        num_classes = len(np.unique(y_train))  # 获取 y_train 中的类别数量
        print(f"Number of classes detected: {num_classes}")

        # 初始化模型
        self.model = EncoderDecoderClassifier(self.input_size, self.hidden_size, num_classes)

        X_train = torch.tensor(X_train, dtype=torch.float32)
        y_train = torch.tensor(y_train, dtype=torch.long)  # 确保 y_train 是整型类别索引

        # 优化器在这里初始化，因为 model 现在才定义好
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr)

        # 训练模型
        self.model.train()
        for epoch in range(self.epochs):
            epoch_loss = 0.0
            for i in range(0, len(X_train), self.batch_size):
                X_batch = X_train[i:i + self.batch_size]
                y_batch = y_train[i:i + self.batch_size]

                outputs = self.model(X_batch)
                loss = self.criterion(outputs, y_batch)

                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                epoch_loss += loss.item()

            # 每10个 epoch 打印损失
            if (epoch + 1) % 10 == 0:
                print(f"Epoch [{epoch+1}/{self.epochs}], Loss: {epoch_loss / len(X_train):.4f}")

    def predict(self, X_test):
        X_test = torch.tensor(X_test, dtype=torch.float32)
        self.model.eval()
        with torch.no_grad():
            outputs = self.model(X_test)
            # 使用 argmax 从 softmax 输出中获得类别索引
            y_pred = torch.argmax(outputs, dim=1).numpy()
        return y_pred


######## VAE #########
class VAEClassifier(nn.Module):
    def __init__(self, input_size, hidden_size, latent_size, output_size):
        super(VAEClassifier, self).__init__()

        # Encoder: 输出均值和对数方差
        self.encoder = nn.Sequential(nn.Linear(input_size, hidden_size), nn.ReLU())
        self.fc_mu = nn.Linear(hidden_size, latent_size)  # 均值
        self.fc_logvar = nn.Linear(hidden_size, latent_size)  # 对数方差

        # 分类器: 在隐变量上添加分类器
        self.classifier = nn.Linear(latent_size, output_size)

    def encode(self, x):
        h = self.encoder(x)
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h)
        return mu, logvar

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std  # 重参数化技巧

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        logits = self.classifier(z)  # 分类
        return logits, mu, logvar  # 返回分类结果和VAE的参数


# 封装的VAE分类器
class VAEClassifierModel:
    def __init__(self, input_size, hidden_size, latent_size, epochs=100, lr=0.001, batch_size=1):
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.latent_size = latent_size
        self.epochs = epochs
        self.lr = lr
        self.batch_size = batch_size
        self.model = None  # 模型会在fit中初始化，依赖于y_train中的类别数
        self.classification_criterion = nn.CrossEntropyLoss()

    def vae_loss(self, reconstruction_loss, mu, logvar):
        # KL散度损失
        kl_divergence = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        return reconstruction_loss + kl_divergence

    def fit(self, X_train, y_train):
        # 自动确定 output_size
        num_classes = len(np.unique(y_train))  # 获取 y_train 中的类别数量
        print(f"Number of classes detected: {num_classes}")

        # 初始化模型
        self.model = VAEClassifier(self.input_size, self.hidden_size, self.latent_size, num_classes)

        X_train = torch.tensor(X_train, dtype=torch.float32)
        y_train = torch.tensor(y_train, dtype=torch.long)  # 确保 y_train 是整型类别索引

        # 优化器在这里初始化，因为 model 现在才定义好
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr)

        # 训练模型
        self.model.train()
        for epoch in range(self.epochs):
            epoch_loss = 0.0
            for i in range(0, len(X_train), self.batch_size):
                X_batch = X_train[i:i + self.batch_size]
                y_batch = y_train[i:i + self.batch_size]

                # 前向传播
                logits, mu, logvar = self.model(X_batch)
                classification_loss = self.classification_criterion(logits, y_batch)
                loss = self.vae_loss(classification_loss, mu, logvar)

                # 反向传播和优化
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                epoch_loss += loss.item()

            # 每10个 epoch 打印损失
            if (epoch + 1) % 10 == 0:
                print(f"Epoch [{epoch + 1}/{self.epochs}], Loss: {epoch_loss / len(X_train):.4f}")

    def predict(self, X_test):
        X_test = torch.tensor(X_test, dtype=torch.float32)
        self.model.eval()
        with torch.no_grad():
            logits, _, _ = self.model(X_test)
            # 使用 argmax 从 softmax 输出中获得类别索引
            y_pred = torch.argmax(logits, dim=1).numpy()
        return y_pred


################################
