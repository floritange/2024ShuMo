import os
import pandas as pd
import matplotlib.pyplot as plt

COUNT = 1


def get_x(data):
    return [i for i in range(0, len(data))]


def fig_nav(comm, name, net):
    global COUNT
    data = pd.read_csv(comm + name[0])
    ap_list = list(set(data['ap_id'].values))
    ap_list = sorted(ap_list, reverse=False)
    for ap in ap_list:
        plt.subplot(4, 3, COUNT)
        title = "_".join([name[0].split('_')[2], net, name[0].split('_')[4].split('.')[0], ap])
        plt.title(title)
        for n in name:
            tmp = pd.read_csv(comm + n)
            tmp = tmp[(tmp['ap_id'] == ap) & (tmp['protocol'] == net)]
            plt.plot(get_x(tmp), tmp['seq_time'].values, label=n.split('_')[3])
            plt.legend()
        COUNT += 1


if __name__ == '__main__':
    comm = os.getcwd() + '/dataset/'
    test = [
        ['training_set_2ap_loc0_nav82.csv', 'training_set_2ap_loc1_nav82.csv', 'training_set_2ap_loc2_nav82.csv'],
        ['training_set_2ap_loc0_nav86.csv', 'training_set_2ap_loc1_nav86.csv'],
        [
            'training_set_3ap_loc30_nav82.csv', 'training_set_3ap_loc31_nav82.csv', 'training_set_3ap_loc32_nav82.csv',
            'training_set_3ap_loc33_nav82.csv'
        ],
        ['training_set_3ap_loc30_nav86.csv', 'training_set_3ap_loc31_nav86.csv', 'training_set_3ap_loc32_nav86.csv'],
    ]
    type_ = 'udp'
    plt.figure(1, figsize=(15, 2 * 3), dpi=300)
    for t in test:
        fig_nav(comm, t, type_)
    plt.subplots_adjust(top=0.95, bottom=0.05, left=0.03, right=0.99, hspace=0.5, wspace=0.15)
    plt.savefig('./output/cov_loc_' + type_ + '.svg')
