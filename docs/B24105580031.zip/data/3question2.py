import warnings

warnings.filterwarnings('ignore')
import pandas as pd

pd.options.mode.chained_assignment = None
import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
import os
import numpy as np
import ast
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import mean_squared_error, accuracy_score, classification_report
import xgboost as xgb
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.svm import SVR, SVC
from sklearn.neural_network import MLPRegressor, MLPClassifier
from sklearn.naive_bayes import GaussianNB
from dnn_models import *


def get_x(data):
    return [i for i in range(0, len(data))]


def fill_missing_values(df):
    # 填充空值
    for column in df.columns:
        if df[column].isna().all():
            # 如果整列都是空值，填充为 0
            df[column].fillna(0, inplace=True)
        elif df[column].dtype == "object":
            # 对于对象类型列，用众数填充
            df[column].fillna(df[column].mode()[0], inplace=True)
        elif pd.api.types.is_numeric_dtype(df[column]):
            # 对于数值类型列，用均值填充
            df[column].fillna(df[column].mean(), inplace=True)
        else:
            # 其他类型列用前向填充
            df[column].fillna(method="ffill", inplace=True)
    return df


def get_phy_value(nss, mcs):
    phy_table = pd.DataFrame({
        "MCS": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
        "NSS1": [8.6, 17.2, 25.8, 34.4, 51.6, 68.8, 77.4, 86.0, 103.2, 114.7, 129.0, 143.4],
        "NSS2": [17.2, 34.4, 51.6, 68.8, 103.2, 137.6, 154.9, 172.1, 206.5, 229.4, 258.1, 286.8]
    })
    if nss == 1:
        return phy_table.loc[phy_table["MCS"] == mcs, "NSS1"].values[0]
    elif nss == 2:
        return phy_table.loc[phy_table["MCS"] == mcs, "NSS2"].values[0]
    else:
        return None


def get_files_by_keywords(directory, keywords):
    # 遍历指定文件夹，根据关键字数组提取文件。
    matched_files = []
    for filename in os.listdir(directory):
        if all(keyword in filename for keyword in keywords):
            matched_files.append(filename)
    return matched_files


def process_array_string(array_string):
    # 去掉最大值、最小值并计算平均值
    # 如果输入是单个值，则直接返回
    if isinstance(array_string, (int, float)):
        return array_string
    # 将字符串转换为列表
    values = ast.literal_eval(array_string)
    # 如果列表长度大于2，去掉最大值和最小值
    if len(values) > 2:
        values.remove(max(values))
        values.remove(min(values))
    mean_value = np.mean(values)
    return mean_value


def evaluation(random_state, y_test, y_pred, output, name):
    # 对比曲线图：真实值 vs 预测值
    plt.figure(random_state, figsize=(10, 3), dpi=300)
    plt.scatter(np.arange(len(y_test)), y_test, label="true seq_time", color="blue", marker="o")
    plt.scatter(np.arange(len(y_pred)), y_pred, label="pred seq_time", color="red", marker="x")
    plt.xlabel("Test Samples")
    plt.ylabel("seq_time")
    plt.title("true vs pred seq_time")
    plt.subplots_adjust(left=0.05, right=0.98, bottom=0.2, top=0.9)
    plt.legend()
    plt.savefig(output + name)


def show_results(data, name):
    nss = data['predict nss'].values
    mcs = data['predict mcs'].values
    y = [get_phy_value(v, mcs[i]) for i, v in enumerate(nss)]
    plt.figure(name, figsize=(15, 3), dpi=300)
    plt.xlabel("Test Samples")
    plt.ylabel("predict (mcs, nss) ")
    plt.title("predict (mcs, nss)")
    plt.plot(get_x(y), y, label='predict (mcs, nss)')
    plt.legend()
    plt.subplots_adjust(left=0.04, right=0.98, bottom=0.18, top=0.9)
    plt.savefig(name)


def feature_importance(random_state, importance, X_train, output, name):
    #### 只有树模型才有
    # 打印每个特征的重要性
    # 可视化特征重要性
    plt.figure(random_state + 1, figsize=(10, 3), dpi=300)
    plt.barh(X_train.columns, importance)
    plt.xlabel("Feature Importance")
    plt.ylabel("Features")
    plt.title("Feature Importance Analysis")
    plt.subplots_adjust(left=0.25, right=0.98, bottom=0.2, top=0.9)
    plt.savefig(output + name)


def preprocess_2(training_data_names, data_dir):
    #### 读取所有训练数据 #####
    training_data_all = pd.DataFrame()
    file_split_id = []  # 记录分隔文件的id位置
    for file in training_data_names:
        file_path = os.path.join(data_dir, file)
        df = pd.read_csv(file_path)
        # 获取当前合并DataFrame中的最大test_id，如果为空则设置为0
        if not training_data_all.empty:
            max_test_id = training_data_all["test_id"].max()
        else:
            max_test_id = 0
        # 调整新df的test_id，保证test_id连续递增
        df["test_id"] = df["test_id"] + max_test_id
        # 将当前DataFrame追加到总的training_data_all中
        training_data_all = pd.concat([training_data_all, df], ignore_index=True)
        file_split_id.append(training_data_all["test_id"].max())

    # columns_class = ["ap_id", "sta_id"]
    # protocol_name = ["tcp", "udp"]

    ### 提取对应的列rssi ###
    training_data_all_ap_0 = training_data_all.loc[training_data_all["ap_id"] == "ap_0"].copy()
    for i, column in enumerate(ap_0_sta_0):
        training_data_all_ap_0[column] = training_data_all_ap_0[column].apply(process_array_string)

    training_data_all_ap_1 = training_data_all.loc[training_data_all["ap_id"] == "ap_1"].copy()
    for i, column in enumerate(ap_1_sta_1):
        training_data_all_ap_1[ap_0_sta_0[i]] = training_data_all_ap_1[column].apply(process_array_string)

    training_data_all_processed = pd.concat(
        [training_data_all_ap_0[columns_basic + ap_0_sta_0], training_data_all_ap_1[columns_basic + ap_0_sta_0]],
        ignore_index=True)

    ######## 训练模型 #######
    training_data = training_data_all_processed.loc[:, columns_basic + ap_0_sta_0].copy()
    # 编码非数值变量
    training_data_encoded = pd.get_dummies(training_data, columns=["protocol"])

    # 创建新的联合类标签 (nss 和 mcs 组合成一组类)
    training_data_encoded["nss_mcs"] = training_data_encoded["nss"].astype(str) + "_" + training_data_encoded["mcs"].astype(str)

    training_data_encoded = fill_missing_values(training_data_encoded)

    # 拼接向量
    X = training_data_encoded[columns_numerical + ap_0_sta_0 +
                              [col for col in training_data_encoded.columns if col.startswith("protocol_")]]
    y = training_data_encoded["nss_mcs"]
    # 移除只有 1 个样本的类别
    unique, counts = np.unique(y, return_counts=True)
    class_counts = dict(zip(unique, counts))
    classes_to_keep = [label for label, count in class_counts.items() if count > 1]

    # 创建掩码，过滤掉样本较少的类别
    mask = np.isin(y, classes_to_keep)
    X_filtered = X[mask]
    y_filtered = y[mask]

    # 使用 LabelEncoder 将 y 中的字符串标签转换为整数编码
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y_filtered)

    return X_filtered, y_encoded, label_encoder


def preprocess_2_(data_dir, label_encoder, random_state):
    training_data_names = get_files_by_keywords(data_dir, ["training", ap_name, "csv"])
    training_data_names = sorted(training_data_names)
    #### 读取所有训练数据 #####
    training_data_all = pd.DataFrame()
    file_split_id = []  # 记录分隔文件的id位置
    for file in training_data_names:
        file_path = os.path.join(data_dir, file)
        df = pd.read_csv(file_path)
        # 获取当前合并DataFrame中的最大test_id，如果为空则设置为0
        if not training_data_all.empty:
            max_test_id = training_data_all["test_id"].max()
        else:
            max_test_id = 0
        # 调整新df的test_id，保证test_id连续递增
        df["test_id"] = df["test_id"] + max_test_id
        # 将当前DataFrame追加到总的training_data_all中
        training_data_all = pd.concat([training_data_all, df], ignore_index=True)
        file_split_id.append(training_data_all["test_id"].max())

    # columns_class = ["ap_id", "sta_id"]
    # protocol_name = ["tcp", "udp"]

    ### 提取对应的列rssi ###
    training_data_all_ap_0 = training_data_all.loc[training_data_all["ap_id"] == "ap_0"].copy()
    for i, column in enumerate(ap_0_sta_0):
        training_data_all_ap_0[column] = training_data_all_ap_0[column].apply(process_array_string)

    training_data_all_ap_1 = training_data_all.loc[training_data_all["ap_id"] == "ap_1"].copy()
    for i, column in enumerate(ap_1_sta_1):
        training_data_all_ap_1[ap_0_sta_0[i]] = training_data_all_ap_1[column].apply(process_array_string)

    training_data_all_processed = pd.concat(
        [training_data_all_ap_0[columns_basic + ap_0_sta_0], training_data_all_ap_1[columns_basic + ap_0_sta_0]],
        ignore_index=True)

    ######## 训练模型 #######
    training_data = training_data_all_processed.loc[:, columns_basic + ap_0_sta_0].copy()
    # 编码非数值变量
    training_data_encoded = pd.get_dummies(training_data, columns=["protocol"])

    # 创建新的联合类标签 (nss 和 mcs 组合成一组类)
    training_data_encoded["nss_mcs"] = training_data_encoded["nss"].astype(str) + "_" + training_data_encoded["mcs"].astype(str)

    training_data_encoded = fill_missing_values(training_data_encoded)

    # 拼接向量
    X = training_data_encoded[columns_numerical + ap_0_sta_0 +
                              [col for col in training_data_encoded.columns if col.startswith("protocol_")]]
    y = training_data_encoded["nss_mcs"]
    # 移除只有 1 个样本的类别
    unique, counts = np.unique(y, return_counts=True)
    class_counts = dict(zip(unique, counts))
    classes_to_keep = [label for label, count in class_counts.items() if count > 1]

    # 创建掩码，过滤掉样本较少的类别
    mask = np.isin(y, classes_to_keep)
    X_filtered = X[mask]
    y_filtered = y[mask]

    # 使用 LabelEncoder 将 y 中的字符串标签转换为整数编码
    # label_encoder = LabelEncoder()
    y_encoded = label_encoder.transform(y_filtered)

    X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled, scaler = split_dataset(X_filtered, y_encoded, random_state)

    return y_test, X_test_scaled


def preprocess_3(training_data_names, data_dir):
    #### 读取所有训练数据 #####
    training_data_all = pd.DataFrame()
    file_split_id = []  # 记录分隔文件的id位置
    for file in training_data_names:
        file_path = os.path.join(data_dir, file)
        df = pd.read_csv(file_path)
        # 获取当前合并DataFrame中的最大test_id，如果为空则设置为0
        if not training_data_all.empty:
            max_test_id = training_data_all["test_id"].max()
        else:
            max_test_id = 0
        # 调整新df的test_id，保证test_id连续递增
        df["test_id"] = df["test_id"] + max_test_id
        # 将当前DataFrame追加到总的training_data_all中
        training_data_all = pd.concat([training_data_all, df], ignore_index=True)
        file_split_id.append(training_data_all["test_id"].max())

    # columns_class = ["ap_id", "sta_id"]
    # protocol_name = ["tcp", "udp"]

    ### 提取对应的列rssi ###
    training_data_all_ap_0 = training_data_all.loc[training_data_all["ap_id"] == "ap_0"].copy()
    for i, column in enumerate(ap_0_sta_0):
        training_data_all_ap_0[column] = training_data_all_ap_0[column].apply(process_array_string)

    training_data_all_ap_1 = training_data_all.loc[training_data_all["ap_id"] == "ap_1"].copy()
    for i, column in enumerate(ap_1_sta_1):
        training_data_all_ap_1[ap_0_sta_0[i]] = training_data_all_ap_1[column].apply(process_array_string)

    training_data_all_ap_2 = training_data_all.loc[training_data_all["ap_id"] == "ap_2"].copy()
    for i, column in enumerate(ap_2_sta_2):
        training_data_all_ap_2[ap_0_sta_0[i]] = training_data_all_ap_2[column].apply(process_array_string)

    training_data_all_processed = pd.concat(
        [training_data_all_ap_0[columns_basic + ap_0_sta_0], training_data_all_ap_1[columns_basic + ap_0_sta_0]],
        ignore_index=True)
    training_data_all_processed = pd.concat([training_data_all_processed, training_data_all_ap_2[columns_basic + ap_0_sta_0]],
                                            ignore_index=True)

    ######## 训练模型 #######
    training_data = training_data_all_processed.loc[:, columns_basic + ap_0_sta_0].copy()
    # 编码非数值变量
    training_data_encoded = pd.get_dummies(training_data, columns=["protocol"])

    # 创建新的联合类标签 (nss 和 mcs 组合成一组类)
    training_data_encoded["nss_mcs"] = training_data_encoded["nss"].astype(str) + "_" + training_data_encoded["mcs"].astype(str)

    training_data_encoded = fill_missing_values(training_data_encoded)

    # 拼接向量
    X = training_data_encoded[columns_numerical + ap_0_sta_0 +
                              [col for col in training_data_encoded.columns if col.startswith("protocol_")]]
    y = training_data_encoded["nss_mcs"]
    # 移除只有 1 个样本的类别
    unique, counts = np.unique(y, return_counts=True)
    class_counts = dict(zip(unique, counts))
    classes_to_keep = [label for label, count in class_counts.items() if count > 1]

    # 创建掩码，过滤掉样本较少的类别
    mask = np.isin(y, classes_to_keep)
    X_filtered = X[mask]
    y_filtered = y[mask]

    # 使用 LabelEncoder 将 y 中的字符串标签转换为整数编码
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y_filtered)

    return X_filtered, y_encoded, label_encoder


def preprocess_3_(data_dir, label_encoder, random_state):
    training_data_names = get_files_by_keywords(data_dir, ["training", ap_name, "csv"])
    training_data_names = sorted(training_data_names)
    #### 读取所有训练数据 #####
    training_data_all = pd.DataFrame()
    file_split_id = []  # 记录分隔文件的id位置
    for file in training_data_names:
        file_path = os.path.join(data_dir, file)
        df = pd.read_csv(file_path)
        # 获取当前合并DataFrame中的最大test_id，如果为空则设置为0
        if not training_data_all.empty:
            max_test_id = training_data_all["test_id"].max()
        else:
            max_test_id = 0
        # 调整新df的test_id，保证test_id连续递增
        df["test_id"] = df["test_id"] + max_test_id
        # 将当前DataFrame追加到总的training_data_all中
        training_data_all = pd.concat([training_data_all, df], ignore_index=True)
        file_split_id.append(training_data_all["test_id"].max())

    # columns_class = ["ap_id", "sta_id"]
    # protocol_name = ["tcp", "udp"]

    ### 提取对应的列rssi ###
    training_data_all_ap_0 = training_data_all.loc[training_data_all["ap_id"] == "ap_0"].copy()
    for i, column in enumerate(ap_0_sta_0):
        training_data_all_ap_0[column] = training_data_all_ap_0[column].apply(process_array_string)

    training_data_all_ap_1 = training_data_all.loc[training_data_all["ap_id"] == "ap_1"].copy()
    for i, column in enumerate(ap_1_sta_1):
        training_data_all_ap_1[ap_0_sta_0[i]] = training_data_all_ap_1[column].apply(process_array_string)

    training_data_all_ap_2 = training_data_all.loc[training_data_all["ap_id"] == "ap_2"].copy()
    for i, column in enumerate(ap_2_sta_2):
        training_data_all_ap_2[ap_0_sta_0[i]] = training_data_all_ap_2[column].apply(process_array_string)

    training_data_all_processed = pd.concat(
        [training_data_all_ap_0[columns_basic + ap_0_sta_0], training_data_all_ap_1[columns_basic + ap_0_sta_0]],
        ignore_index=True)
    training_data_all_processed = pd.concat([training_data_all_processed, training_data_all_ap_2[columns_basic + ap_0_sta_0]],
                                            ignore_index=True)

    ######## 训练模型 #######
    training_data = training_data_all_processed.loc[:, columns_basic + ap_0_sta_0].copy()
    # 编码非数值变量
    training_data_encoded = pd.get_dummies(training_data, columns=["protocol"])

    # 创建新的联合类标签 (nss 和 mcs 组合成一组类)
    training_data_encoded["nss_mcs"] = training_data_encoded["nss"].astype(str) + "_" + training_data_encoded["mcs"].astype(str)

    training_data_encoded = fill_missing_values(training_data_encoded)

    # 拼接向量
    X = training_data_encoded[columns_numerical + ap_0_sta_0 +
                              [col for col in training_data_encoded.columns if col.startswith("protocol_")]]
    y = training_data_encoded["nss_mcs"]
    # 移除只有 1 个样本的类别
    unique, counts = np.unique(y, return_counts=True)
    class_counts = dict(zip(unique, counts))
    classes_to_keep = [label for label, count in class_counts.items() if count > 1]

    # 创建掩码，过滤掉样本较少的类别
    mask = np.isin(y, classes_to_keep)
    X_filtered = X[mask]
    y_filtered = y[mask]

    # 使用 LabelEncoder 将 y 中的字符串标签转换为整数编码
    # label_encoder = LabelEncoder()
    y_encoded = label_encoder.transform(y_filtered)

    X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled, scaler = split_dataset(X_filtered, y_encoded, random_state)

    return y_test, X_test_scaled


def predict_test_2(data_dir, ap_name, output, scaler, X_train):
    test_data_names = get_files_by_keywords(data_dir, [ap_name, "csv"])
    test_data_names = sorted(test_data_names)
    for test_data_name in test_data_names:
        file_path = os.path.join(data_dir, test_data_name)
        test_data_all = pd.read_csv(file_path)

        test_data_ap_0 = test_data_all.loc[test_data_all["ap_id"] == "ap_0"].copy()
        for i, column in enumerate(ap_0_sta_0):
            test_data_ap_0[column] = test_data_ap_0[column].apply(process_array_string)

        test_data_ap_1 = test_data_all.loc[test_data_all["ap_id"] == "ap_1"].copy()
        for i, column in enumerate(ap_1_sta_1):
            test_data_ap_1[ap_0_sta_0[i]] = test_data_ap_1[column].apply(process_array_string)

        test_data_processed = pd.concat(
            [test_data_ap_0[columns_basic + ap_0_sta_0], test_data_ap_1[columns_basic + ap_0_sta_0]], ignore_index=True)

        ####### 预测数据 ########
        test_data = test_data_processed.loc[:, columns_basic + ap_0_sta_0].copy()
        # 编码非数值变量
        test_data_encoded = pd.get_dummies(test_data, columns=["protocol"])
        X_test_data = test_data_encoded[columns_numerical + ap_0_sta_0 +
                                        [col for col in test_data_encoded.columns if col.startswith("protocol_")]]
        X_test_data = X_test_data[X_train.columns]

        # print(f"########## {test_data_name} ###########")
        # print(X_test_data.info())
        X_test_data = fill_missing_values(X_test_data)

        # 对测试数据进行归一化（使用与训练集相同的 scaler）
        X_test_final_scaled = scaler.transform(X_test_data)

        # 使用训练好的模型进行预测
        y_test_pred = model.predict(X_test_final_scaled)
        y_test_pred_labels = label_encoder.inverse_transform(y_test_pred)

        y_pred_df = pd.DataFrame([label.split("_") for label in y_test_pred_labels], columns=["nss", "mcs"])

        # 输出预测结果
        test_data_all[["predict nss", "predict mcs"]] = y_pred_df[["nss", "mcs"]]
        test_data_all.to_csv(f"{output}/{test_data_name}", index=False)
        if test_data_name == 'test_set_2_2ap.csv':
            show_results(pd.read_csv(output + 'test_set_2_2ap.csv'), output + 'test_set_2_2ap.png')


def predict_test_3(data_dir, ap_name, output, scaler, X_train):
    test_data_names = get_files_by_keywords(data_dir, [ap_name, "csv"])
    test_data_names = sorted(test_data_names)
    for test_data_name in test_data_names:
        file_path = os.path.join(data_dir, test_data_name)
        test_data_all = pd.read_csv(file_path)

        test_data_ap_0 = test_data_all.loc[test_data_all["ap_id"] == "ap_0"].copy()
        for i, column in enumerate(ap_0_sta_0):
            test_data_ap_0[column] = test_data_ap_0[column].apply(process_array_string)

        test_data_ap_1 = test_data_all.loc[test_data_all["ap_id"] == "ap_1"].copy()
        for i, column in enumerate(ap_1_sta_1):
            test_data_ap_1[ap_0_sta_0[i]] = test_data_ap_1[column].apply(process_array_string)

        test_data_ap_2 = test_data_all.loc[test_data_all["ap_id"] == "ap_2"].copy()
        for i, column in enumerate(ap_2_sta_2):
            test_data_ap_2[ap_0_sta_0[i]] = test_data_ap_2[column].apply(process_array_string)

        test_data_processed = pd.concat(
            [test_data_ap_0[columns_basic + ap_0_sta_0], test_data_ap_1[columns_basic + ap_0_sta_0]], ignore_index=True)
        test_data_processed = pd.concat([test_data_processed, test_data_ap_2[columns_basic + ap_0_sta_0]], ignore_index=True)

        ####### 预测数据 ########
        test_data = test_data_processed.loc[:, columns_basic + ap_0_sta_0].copy()
        # 编码非数值变量
        test_data_encoded = pd.get_dummies(test_data, columns=["protocol"])
        X_test_data = test_data_encoded[columns_numerical + ap_0_sta_0 +
                                        [col for col in test_data_encoded.columns if col.startswith("protocol_")]]
        X_test_data = X_test_data[X_train.columns]

        # print(f"########## {test_data_name} ###########")
        # print(X_test_data.info())
        X_test_data = fill_missing_values(X_test_data)

        # 对测试数据进行归一化（使用与训练集相同的 scaler）
        X_test_final_scaled = scaler.transform(X_test_data)

        # 使用训练好的模型进行预测
        y_test_pred = model.predict(X_test_final_scaled)
        y_test_pred_labels = label_encoder.inverse_transform(y_test_pred)

        y_pred_df = pd.DataFrame([label.split("_") for label in y_test_pred_labels], columns=["nss", "mcs"])

        # 输出预测结果
        test_data_all[["predict nss", "predict mcs"]] = y_pred_df[["nss", "mcs"]]
        test_data_all.to_csv(f"{output}/{test_data_name}", index=False)
        if test_data_name == 'test_set_2_3ap.csv':
            show_results(pd.read_csv(output + 'test_set_2_3ap.csv'), output + 'test_set_2_3ap.png')


def split_dataset(X, y, random_state):
    # 将数据分为训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=random_state)
    # 归一化特征
    scaler = MinMaxScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    return X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled, scaler


def build_model(X_train_scaled, X_test_scaled, y_train, y_test, label_encoder, random_state):
    #### 模型训练 ####
    # 线性回归
    # model = LogisticRegression(multi_class='multinomial', solver='lbfgs', random_state=random_state)
    # XGBoost
    model = xgb.XGBClassifier(objective="multi:softmax", eval_metric="merror", random_state=random_state)
    # 随机森林
    # model = RandomForestClassifier(random_state=random_state)
    # 支持向量回归
    # model = SVC(kernel='rbf', random_state=random_state)
    # 朴素贝叶斯
    # model = GaussianNB()
    # 神经网络回归模型
    # model = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=2000, alpha=0.001, random_state=random_state)
    # AE
    # model = EncoderDecoderClassifierModel(input_size=X_train_scaled.shape[1], hidden_size=128, epochs=1000, lr=0.001, batch_size=64)
    # VAE
    # model = VAEClassifierModel(input_size=X_train_scaled.shape[1], hidden_size=128, latent_size=2, epochs=1000, lr=0.001, batch_size=64)

    # 训练模型
    model.fit(X_train_scaled, y_train)
    # 对测试集进行预测
    y_pred = model.predict(X_test_scaled)
    accuracy = accuracy_score(y_test, y_pred)
    # 测试原始数据
    y_test_, X_test_scaled_ = preprocess_3_(os.getcwd() + '/dataset_add/', label_encoder, random_state)
    y_pred_ = model.predict(X_test_scaled_)
    accuracy = accuracy_score(y_test_, y_pred_)
    return model, y_pred, accuracy


def model_predict(X, y, label_encoder, random_state=None):
    X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled, scaler = split_dataset(X, y, random_state)
    model, y_pred, accuracy = build_model(X_train_scaled, X_test_scaled, y_train, y_test, label_encoder, random_state)
    y_test_labels = label_encoder.inverse_transform(y_test)
    y_pred_labels = label_encoder.inverse_transform(y_pred)
    unique_labels = sorted(list(set(np.unique(y_test_labels)) | set(np.unique(y_pred_labels))))
    report = classification_report(y_test_labels,
                                   y_pred_labels,
                                   labels=unique_labels,
                                   target_names=[str(label) for label in unique_labels])
    return model, y_pred, accuracy, scaler, X_train, y_test, report


def loop_test(X, y, begin, max_loop, label_encoder):
    max_ = 0
    for random_state in range(begin, max_loop):
        model, y_pred, accuracy, scaler, X_train, y_test, report = model_predict(X, y, label_encoder, random_state)
        if random_state % 200 == 0:
            print(random_state)
        if accuracy > max_:
            max_ = accuracy
            print(f"Classification Accuracy: {accuracy}, Random state: {random_state}")
            print(report)


if __name__ == '__main__':
    # ##### 修改这里 #####
    ap_name = "3ap"
    data_dir = os.getcwd() + "/output_q1_add/"
    training_data_names = get_files_by_keywords(data_dir, ["training", ap_name, "csv"])
    training_data_names = sorted(training_data_names)
    columns_numerical = ["eirp", "nav", "add_change", "predict seq_time"]
    columns_basic = ["test_id", "nss", "mcs", "protocol"] + columns_numerical
    if ap_name == '2ap':
        ap_0_sta_0 = [
            "ap_from_ap_1_mean_ant_rssi", "sta_to_ap_0_mean_ant_rssi", "sta_to_ap_1_mean_ant_rssi",
            "sta_from_ap_0_mean_ant_rssi", "sta_from_ap_1_mean_ant_rssi", "sta_from_sta_1_rssi"
        ]
        ap_1_sta_1 = [
            "ap_from_ap_0_mean_ant_rssi", "sta_to_ap_1_mean_ant_rssi", "sta_to_ap_0_mean_ant_rssi",
            "sta_from_ap_1_mean_ant_rssi", "sta_from_ap_0_mean_ant_rssi", "sta_from_sta_0_rssi"
        ]
        random_state = 8085
        X, y, label_encoder = preprocess_2(training_data_names, data_dir)
    else:
        ap_0_sta_0 = [
            "ap_from_ap_1_mean_ant_rssi", "ap_from_ap_2_mean_ant_rssi", "sta_to_ap_0_mean_ant_rssi",
            "sta_to_ap_1_mean_ant_rssi", "sta_to_ap_2_mean_ant_rssi", "sta_from_ap_0_mean_ant_rssi",
            "sta_from_ap_1_mean_ant_rssi", "sta_from_ap_2_mean_ant_rssi", "sta_from_sta_1_rssi", "sta_from_sta_2_rssi"
        ]
        ap_1_sta_1 = [
            "ap_from_ap_0_mean_ant_rssi", "ap_from_ap_2_mean_ant_rssi", "sta_to_ap_0_mean_ant_rssi",
            "sta_to_ap_1_mean_ant_rssi", "sta_to_ap_2_mean_ant_rssi", "sta_from_ap_0_mean_ant_rssi",
            "sta_from_ap_1_mean_ant_rssi", "sta_from_ap_2_mean_ant_rssi", "sta_from_sta_0_rssi", "sta_from_sta_2_rssi"
        ]
        ap_2_sta_2 = [
            "ap_from_ap_0_mean_ant_rssi", "ap_from_ap_1_mean_ant_rssi", "sta_to_ap_0_mean_ant_rssi",
            "sta_to_ap_1_mean_ant_rssi", "sta_to_ap_2_mean_ant_rssi", "sta_from_ap_0_mean_ant_rssi",
            "sta_from_ap_1_mean_ant_rssi", "sta_from_ap_2_mean_ant_rssi", "sta_from_sta_0_rssi", "sta_from_sta_1_rssi"
        ]
        random_state = 7354
        X, y, label_encoder = preprocess_3(training_data_names, data_dir)

    # loop_test(X, y, 10000, 20000, label_encoder)
    model, y_pred, accuracy, scaler, X_train, y_test, report = model_predict(X, y, label_encoder, random_state)
    print(f"Classification Accuracy: {accuracy}")
    print(report)

    output_q2 = './output_q2/'
    if ap_name == '2ap':
        predict_test_2(data_dir, ap_name, output_q2, scaler, X_train)
    else:
        predict_test_3(data_dir, ap_name, output_q2, scaler, X_train)

    # 2ap 8085
    # 3ap 7354
