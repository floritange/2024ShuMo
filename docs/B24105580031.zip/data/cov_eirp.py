import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

COUNT = 1


def get_x(data):
    return [i for i in range(0, len(data))]


def normalize(arr):
    min_value = min(arr)
    max_value = max(arr)

    if max_value == min_value:
        return [0] * len(arr)

    normalized_arr = [(x - min_value) / (max_value - min_value) for x in arr]
    return normalized_arr


def fig_nav(comm, name, net):
    global COUNT
    seq_time_ = []
    eirp_ = []
    for n in name:
        tmp = pd.read_csv(comm + n)
        tmp = tmp[(tmp['protocol'] == net)]
        if len(seq_time_) == 0:
            seq_time_ = tmp['seq_time'].values
            eirp_ = tmp['eirp'].values
        seq_time_ = np.hstack([seq_time_, tmp['seq_time'].values])
        eirp_ = np.hstack([eirp_, tmp['eirp'].values])
    plt.subplot(2, 1, COUNT)
    title = "_".join([name[0].split('_')[2], net])
    plt.title(title)
    plt.plot(get_x(seq_time_), normalize(seq_time_), label='seq_time')
    plt.plot(get_x(eirp_), normalize(eirp_), label='eirp')
    plt.legend()
    COUNT += 1


if __name__ == '__main__':
    comm = os.getcwd() + '/dataset/'
    test = [
        [
            'training_set_2ap_loc0_nav82.csv', 'training_set_2ap_loc0_nav86.csv', 'training_set_2ap_loc1_nav82.csv',
            'training_set_2ap_loc1_nav86.csv', 'training_set_2ap_loc2_nav82.csv'
        ],
        [
            'training_set_3ap_loc30_nav82.csv', 'training_set_3ap_loc30_nav86.csv', 'training_set_3ap_loc31_nav82.csv',
            'training_set_3ap_loc31_nav86.csv', 'training_set_3ap_loc32_nav82.csv', 'training_set_3ap_loc32_nav86.csv',
            'training_set_3ap_loc33_nav82.csv', 'training_set_3ap_loc33_nav88.csv'
        ],
    ]
    type_ = 'tcp'
    plt.figure(1, figsize=(15, 2 * 2), dpi=300)
    for t in test:
        fig_nav(comm, t, type_)
    plt.subplots_adjust(top=0.93, bottom=0.07, left=0.03, right=0.99, hspace=0.35, wspace=0.15)
    plt.savefig('./output/cov_eirp_' + type_ + '.svg')
