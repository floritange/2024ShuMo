import os
import pandas as pd
import matplotlib.pyplot as plt

COUNT = 1


def get_x(data):
    return [i for i in range(0, len(data))]


def normalize(arr):
    min_value = min(arr)
    max_value = max(arr)

    if max_value == min_value:
        return [0] * len(arr)

    normalized_arr = [(x - min_value) / (max_value - min_value) for x in arr]
    return normalized_arr


def fig_nav(comm, name):
    global COUNT
    data = pd.read_csv(comm + name[0])
    ap_list = list(set(data['ap_id'].values))
    ap_list = sorted(ap_list, reverse=False)
    for ap in ap_list:
        plt.subplot(8, 4, COUNT)
        title = "_".join([name[0].split('_')[2], name[0].split('_')[4].split('.')[0], ap])
        plt.title(title)
        for n in name:
            tmp = pd.read_csv(comm + n)
            tmp = tmp[(tmp['ap_id'] == ap) & (tmp['protocol'] == 'tcp')]
            plt.plot(get_x(tmp), normalize(tmp['seq_time'].values), label='tcp')
            tmp = pd.read_csv(comm + n)
            tmp = tmp[(tmp['ap_id'] == ap) & (tmp['protocol'] == 'udp')]
            plt.plot(get_x(tmp), normalize(tmp['seq_time'].values), label='udp')
            plt.plot(get_x(tmp), normalize(tmp['eirp'].values), label='eirp')
            plt.legend()
        COUNT += 1


if __name__ == '__main__':
    comm = os.getcwd() + '/dataset/'
    test = [
        ['training_set_2ap_loc0_nav82.csv'],
        ['training_set_2ap_loc0_nav86.csv'],
        ['training_set_2ap_loc1_nav82.csv'],
        ['training_set_2ap_loc1_nav86.csv'],
        ['training_set_3ap_loc30_nav82.csv'],
        ['training_set_3ap_loc30_nav86.csv'],
        ['training_set_3ap_loc31_nav82.csv'],
        ['training_set_3ap_loc31_nav86.csv'],
        ['training_set_3ap_loc32_nav82.csv'],
        ['training_set_3ap_loc32_nav86.csv'],
        ['training_set_3ap_loc33_nav82.csv'],
        ['training_set_3ap_loc33_nav88.csv'],
    ]
    plt.figure(1, figsize=(15, 2 * 8), dpi=300)
    for t in test:
        fig_nav(comm, t)
    plt.subplots_adjust(top=0.97, bottom=0.03, left=0.03, right=0.99, hspace=0.5, wspace=0.15)
    plt.savefig('./output/cov_proto.svg')
