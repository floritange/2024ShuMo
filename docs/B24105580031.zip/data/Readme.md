### 代码说明
运行代码需要先确认是否已经安装以下环境，如果需要安装请使用如下命令：
```bash
pip install -r requirements.txt
```
#### 目录结构与文件说明
1. 数据分析与观察文件，将会输出对应的图片到`ouput`文件夹
   - cov_eirp.py
   - cov_loc.py
   - cov_nav.py
   - cov_proto.py
2. 问题一解答代码：1question1.py，输出路径：`output_q1`文件夹。
3. 问题二解答代码：3question2.py，输出路径：`output_q2`文件夹。
4. 问题三解答代码：4question3.py，输出路径：`output_q3`文件夹。
5. 中间过程的代码：2addcolumn.py，输出路径：`output_q1_add`文件夹。
6. 数据增强的代码：enhancing.py，原始数据集目录：`dataset`，增强数据集目录：`dataset_enhance`。
7. 神经网络代码：dnn_models.py。
8. 其他，输入的参数数据集：`input_param`，数据精确率计算的辅助数据集`dataset_add`。

#### 代码运行说明
运行测试代码需要按照1,2,3,4标记的顺序进行。每个步骤需要上一个步骤的输出作为输入。
```bash
# 问题一解答
python 1question1.py
# 新增特征列
python 2addcolumn.py
# 问题二解答
python 3question2.py
# 问题三解答
python 4question3.py

# 数据增强
python enhancing.py
```
注意：
- 代码中的模型已经预置为XGBoost模型，需要调整模型可修改每个问题解答代码中的`build_model`函数。
- 切换2AP模型与3AP模型需要修改每个问题解答代码中的`if __name__ == '__main__':`部分的`ap_name = "3ap"`为对应模型。